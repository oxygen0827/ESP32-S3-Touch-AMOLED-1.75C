#!/usr/bin/env sh
set -eu
PORT="${1:-}"
if [ -z "$PORT" ]; then
    echo "Usage: $0 /dev/ttyUSB0"
    exit 2
fi
cd "$(dirname "$0")"
'python' '-m' 'esptool' '--chip' 'esp32s3' '--port' $PORT '--baud' '460800' '--before' 'default_reset' '--after' 'hard_reset' 'write_flash' '0x0' 'bin/01_HelloWorld.ino.merged.bin'
