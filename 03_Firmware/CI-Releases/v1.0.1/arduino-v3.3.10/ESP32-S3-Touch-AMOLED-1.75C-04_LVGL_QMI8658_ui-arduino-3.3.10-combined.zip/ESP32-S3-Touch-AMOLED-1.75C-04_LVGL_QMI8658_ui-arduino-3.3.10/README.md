# ESP32-S3-Touch-AMOLED-1.75C-04_LVGL_QMI8658_ui-arduino-3.3.10

Install esptool if needed:

```bash
python -m pip install esptool
```

## Combined firmware (recommended)

Flash the single combined image from this directory:

```bash
./flash_combined.sh /dev/ttyUSB0
```

On Windows:

```bat
flash_combined.bat COMx
```

The combined image is written at offset `0x0`. The equivalent complete command is recorded in
`flash_combined_args.txt`.

## Split firmware

The original offset-addressed binaries are also included. Flash them with:

```bash
./flash.sh /dev/ttyUSB0
```

On Windows:

```bat
flash.bat COMx
```

The split-image command is recorded in `flash_args.txt`. Use firmware built for this exact board;
mixing bootloaders, partition tables, and applications from different packages is not supported.
