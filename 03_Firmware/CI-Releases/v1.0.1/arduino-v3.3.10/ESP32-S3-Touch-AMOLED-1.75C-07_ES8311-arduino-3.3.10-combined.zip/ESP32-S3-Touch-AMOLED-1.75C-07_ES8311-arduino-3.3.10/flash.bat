@echo off
set PORT=%1
if "%PORT%"=="" (
  echo Usage: flash.bat COMx
  exit /b 2
)
cd /d %~dp0
"python" "-m" "esptool" "--chip" "esp32s3" "--port" %PORT% "--baud" "460800" "--before" "default_reset" "--after" "hard_reset" "write_flash" "0x0" "bin/15_ES8311.ino.merged.bin"
