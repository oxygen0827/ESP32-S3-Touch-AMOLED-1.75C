@echo off
set PORT=%1
if "%PORT%"=="" (
  echo Usage: flash_combined.bat COMx
  exit /b 2
)
cd /d %~dp0
"python" "-m" "esptool" "--chip" "esp32s3" "--port" %PORT% "--baud" "460800" "--before" "default_reset" "--after" "hard_reset" "write_flash" "--flash_mode" "dio" "--flash_size" "32MB" "--flash_freq" "80m" "0x0" "bin/ESP32-S3-Touch-AMOLED-1.75C-02_lvgl_demo_v9-v5.5.4-combined.bin"
