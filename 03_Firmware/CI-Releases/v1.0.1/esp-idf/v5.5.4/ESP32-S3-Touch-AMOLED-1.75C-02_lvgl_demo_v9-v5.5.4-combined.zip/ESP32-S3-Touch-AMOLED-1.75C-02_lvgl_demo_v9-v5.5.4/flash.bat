@echo off
set PORT=%1
if "%PORT%"=="" (
  echo Usage: flash.bat COMx
  exit /b 2
)
cd /d %~dp0
"python" "-m" "esptool" "--chip" "esp32s3" "--port" %PORT% "--baud" "460800" "--before" "default_reset" "--after" "hard_reset" "write_flash" "--flash_mode" "dio" "--flash_size" "32MB" "--flash_freq" "80m" "0x0" "bin/0x0_bootloader.bin" "0x8000" "bin/0x8000_partition-table.bin" "0x10000" "bin/0x10000_lvgl_demo_v9.bin"
