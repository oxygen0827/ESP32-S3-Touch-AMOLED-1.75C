#!/usr/bin/env sh
set -eu
PORT="${1:-}"
if [ -z "$PORT" ]; then
    echo "Usage: $0 /dev/ttyUSB0"
    exit 2
fi
cd "$(dirname "$0")"
'python' '-m' 'esptool' '--chip' 'esp32s3' '--port' $PORT '--baud' '460800' '--before' 'default_reset' '--after' 'hard_reset' 'write_flash' '--flash_mode' 'dio' '--flash_size' '16MB' '--flash_freq' '80m' '0x0' 'bin/0x0_bootloader.bin' '0x8000' 'bin/0x8000_partition-table.bin' '0x10000' 'bin/0x10000_hello_world.bin'
