#!/usr/bin/env sh
set -eu
PORT="${1:-}"
if [ -z "$PORT" ]; then
    echo "Usage: $0 /dev/ttyUSB0"
    exit 2
fi
cd "$(dirname "$0")"
'python' '-m' 'esptool' '--chip' 'esp32s3' '--port' $PORT '--baud' '460800' '--before' 'default-reset' '--after' 'hard-reset' 'write_flash' '--flash-mode' 'dio' '--flash-size' '2MB' '--flash-freq' '80m' '0x0' 'bin/ESP32-S3-Touch-AMOLED-1.75C-01_AXP2101-v6.0.2-combined.bin'
