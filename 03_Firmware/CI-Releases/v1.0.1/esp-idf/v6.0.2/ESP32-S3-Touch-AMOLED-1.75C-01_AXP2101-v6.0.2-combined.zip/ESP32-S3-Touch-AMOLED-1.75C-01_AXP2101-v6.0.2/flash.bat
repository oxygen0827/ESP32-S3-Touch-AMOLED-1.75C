@echo off
set PORT=%1
if "%PORT%"=="" (
  echo Usage: flash.bat COMx
  exit /b 2
)
cd /d %~dp0
"python" "-m" "esptool" "--chip" "esp32s3" "--port" %PORT% "--baud" "460800" "--before" "default-reset" "--after" "hard-reset" "write_flash" "--flash-mode" "dio" "--flash-size" "2MB" "--flash-freq" "80m" "0x0" "bin/0x0_bootloader.bin" "0x8000" "bin/0x8000_partition-table.bin" "0x10000" "bin/0x10000_axp2101_example.bin"
