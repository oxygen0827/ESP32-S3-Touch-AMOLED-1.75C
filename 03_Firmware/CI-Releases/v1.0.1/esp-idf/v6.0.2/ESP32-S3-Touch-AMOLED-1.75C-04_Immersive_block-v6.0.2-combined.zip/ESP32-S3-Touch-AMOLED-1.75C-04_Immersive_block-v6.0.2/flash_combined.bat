@echo off
set PORT=%1
if "%PORT%"=="" (
  echo Usage: flash_combined.bat COMx
  exit /b 2
)
cd /d %~dp0
"python" "-m" "esptool" "--chip" "esp32s3" "--port" %PORT% "--baud" "460800" "--before" "default-reset" "--after" "hard-reset" "write_flash" "--flash-mode" "dio" "--flash-size" "16MB" "--flash-freq" "80m" "0x0" "bin/ESP32-S3-Touch-AMOLED-1.75C-04_Immersive_block-v6.0.2-combined.bin"
